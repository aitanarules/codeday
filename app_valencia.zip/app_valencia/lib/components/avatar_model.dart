import '/backend/supabase/supabase.dart';
import '/components/avatar_def_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'avatar_widget.dart' show AvatarWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AvatarModel extends FlutterFlowModel<AvatarWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for AvatarDef component.
  late AvatarDefModel avatarDefModel;

  @override
  void initState(BuildContext context) {
    avatarDefModel = createModel(context, () => AvatarDefModel());
  }

  @override
  void dispose() {
    avatarDefModel.dispose();
  }
}
