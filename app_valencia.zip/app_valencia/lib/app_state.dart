import 'package:flutter/material.dart';
import 'backend/api_requests/api_manager.dart';
import 'backend/supabase/supabase.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  String _idUser = 'b9961c48-7abd-4b92-9f41-0ef9a573488f';
  String get idUser => _idUser;
  set idUser(String _value) {
    _idUser = _value;
  }

  String _idImage = '35b1b392-72d5-48b2-959a-9b74d725f064';
  String get idImage => _idImage;
  set idImage(String _value) {
    _idImage = _value;
  }

  String _idTown = '';
  String get idTown => _idTown;
  set idTown(String _value) {
    _idTown = _value;
  }

  String _idStop = '7e47f1b4-c630-4ad0-ab7e-0cc32419ab1f';
  String get idStop => _idStop;
  set idStop(String _value) {
    _idStop = _value;
  }

  String _idReward = '';
  String get idReward => _idReward;
  set idReward(String _value) {
    _idReward = _value;
  }

  String _idQuiz = 'fde5c8fa-28e7-434e-9ee5-3536e6b35b9b';
  String get idQuiz => _idQuiz;
  set idQuiz(String _value) {
    _idQuiz = _value;
  }

  String _idAvatar = '35b1b392-72d5-48b2-959a-9b74d725f064';
  String get idAvatar => _idAvatar;
  set idAvatar(String _value) {
    _idAvatar = _value;
  }

  bool _showDetallesButtom = false;
  bool get showDetallesButtom => _showDetallesButtom;
  set showDetallesButtom(bool _value) {
    _showDetallesButtom = _value;
  }

  bool _comingFromMapa2D = false;
  bool get comingFromMapa2D => _comingFromMapa2D;
  set comingFromMapa2D(bool _value) {
    _comingFromMapa2D = _value;
  }

  bool _logroObtenido = false;
  bool get logroObtenido => _logroObtenido;
  set logroObtenido(bool _value) {
    _logroObtenido = _value;
  }
}
