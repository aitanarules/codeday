import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_timer.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:math';
import 'package:stop_watch_timer/stop_watch_timer.dart';
import 'quiz_page1_widget.dart' show QuizPage1Widget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:provider/provider.dart';

class QuizPage1Model extends FlutterFlowModel<QuizPage1Widget> {
  ///  Local state fields for this page.

  int numQuestion = 0;

  List<String> ansList = [];
  void addToAnsList(String item) => ansList.add(item);
  void removeFromAnsList(String item) => ansList.remove(item);
  void removeAtIndexFromAnsList(int index) => ansList.removeAt(index);
  void insertAtIndexInAnsList(int index, String item) =>
      ansList.insert(index, item);
  void updateAnsListAtIndex(int index, Function(String) updateFn) =>
      ansList[index] = updateFn(ansList[index]);

  String? question;

  bool isCorrect = false;

  int? fieldSelected;

  bool isNotCorrect = false;

  int? numAciertos = 0;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController;
  // State field(s) for Timer1 widget.
  final timer1InitialTimeMs = 5000;
  int timer1Milliseconds = 5000;
  String timer1Value = StopWatchTimer.getDisplayTime(
    5000,
    hours: false,
    minute: false,
    milliSecond: false,
  );
  FlutterFlowTimerController timer1Controller =
      FlutterFlowTimerController(StopWatchTimer(mode: StopWatchMode.countDown));

  // State field(s) for Timer2 widget.
  final timer2InitialTimeMs = 5000;
  int timer2Milliseconds = 5000;
  String timer2Value = StopWatchTimer.getDisplayTime(
    5000,
    hours: false,
    minute: false,
    milliSecond: false,
  );
  FlutterFlowTimerController timer2Controller =
      FlutterFlowTimerController(StopWatchTimer(mode: StopWatchMode.countDown));

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    timer1Controller.dispose();
    timer2Controller.dispose();
  }

  /// Additional helper methods.
  String? get radioButtonValue => radioButtonValueController?.value;
}
