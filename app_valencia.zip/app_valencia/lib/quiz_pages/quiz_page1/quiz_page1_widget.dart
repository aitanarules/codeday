import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_radio_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_timer.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:math';
import 'package:stop_watch_timer/stop_watch_timer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:provider/provider.dart';
import 'quiz_page1_model.dart';
export 'quiz_page1_model.dart';

class QuizPage1Widget extends StatefulWidget {
  const QuizPage1Widget({super.key});

  @override
  State<QuizPage1Widget> createState() => _QuizPage1WidgetState();
}

class _QuizPage1WidgetState extends State<QuizPage1Widget>
    with TickerProviderStateMixin {
  late QuizPage1Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => QuizPage1Model());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      setState(() {
        FFAppState().idUser = 'b9961c48-7abd-4b92-9f41-0ef9a573488f';
        FFAppState().idImage = '067279ff-a077-47f4-99ac-cfef2a3d8953';
        FFAppState().idTown = '9b66ea6d-f144-4e48-a251-1fa9f4232aed';
        FFAppState().idStop = '7e47f1b4-c630-4ad0-ab7e-0cc32419ab1f';
      });
    });

    animationsMap.addAll({
      'textOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: Offset(0.0, 50.0),
            end: Offset(0.0, 0.0),
          ),
        ],
      ),
    });
    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return FutureBuilder<List<QuestionRow>>(
      future: QuestionTable().queryRows(
        queryFn: (q) => q.eq(
          'quizz',
          FFAppState().idQuiz,
        ),
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).alternate,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        List<QuestionRow> quizPage1QuestionRowList = snapshot.data!;
        return GestureDetector(
          onTap: () => _model.unfocusNode.canRequestFocus
              ? FocusScope.of(context).requestFocus(_model.unfocusNode)
              : FocusScope.of(context).unfocus(),
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).alternate,
            appBar: AppBar(
              backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
              automaticallyImplyLeading: false,
              title: FutureBuilder<List<StopRow>>(
                future: StopTable().querySingleRow(
                  queryFn: (q) => q.eq(
                    'id',
                    FFAppState().idStop,
                  ),
                ),
                builder: (context, snapshot) {
                  // Customize what your widget looks like when it's loading.
                  if (!snapshot.hasData) {
                    return Center(
                      child: SizedBox(
                        width: 50.0,
                        height: 50.0,
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                            FlutterFlowTheme.of(context).primary,
                          ),
                        ),
                      ),
                    );
                  }
                  List<StopRow> textStopRowList = snapshot.data!;
                  final textStopRow =
                      textStopRowList.isNotEmpty ? textStopRowList.first : null;
                  return Text(
                    '${textStopRow?.name} Quiz',
                    style: FlutterFlowTheme.of(context).displaySmall.override(
                          fontFamily: 'Noto Sans JP',
                          fontSize: 22.0,
                          letterSpacing: 0.0,
                        ),
                  );
                },
              ),
              actions: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 16.0, 0.0),
                  child: FlutterFlowIconButton(
                    borderColor: Colors.transparent,
                    borderRadius: 30.0,
                    borderWidth: 1.0,
                    buttonSize: 50.0,
                    fillColor: FlutterFlowTheme.of(context).primaryBackground,
                    icon: Icon(
                      Icons.close_rounded,
                      color: FlutterFlowTheme.of(context).secondaryText,
                      size: 30.0,
                    ),
                    onPressed: () async {
                      context.safePop();
                    },
                  ),
                ),
              ],
              centerTitle: false,
              elevation: 0.0,
            ),
            body: Stack(
              children: [
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Align(
                              alignment: AlignmentDirectional(-1.0, 0.0),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    16.0, 12.0, 0.0, 0.0),
                                child: Text(
                                  'Pregunta ${(_model.numQuestion + 1).toString()}/3',
                                  style: FlutterFlowTheme.of(context)
                                      .labelMedium
                                      .override(
                                        fontFamily: 'Noto Sans JP',
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  8.0, 12.0, 8.0, 0.0),
                              child: LinearPercentIndicator(
                                percent: valueOrDefault<double>(
                                  _model.numQuestion / 3,
                                  0.33,
                                ),
                                width: MediaQuery.sizeOf(context).width * 0.96,
                                lineHeight: 12.0,
                                animation: true,
                                animateFromLastPercent: true,
                                progressColor: Color(0xFFC58137),
                                backgroundColor: Color(0xFFE0E3E7),
                                barRadius: Radius.circular(24.0),
                                padding: EdgeInsets.zero,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  16.0, 100.0, 0.0, 0.0),
                              child: FutureBuilder<List<QuestionRow>>(
                                future: QuestionTable().queryRows(
                                  queryFn: (q) => q.eq(
                                    'quizz',
                                    FFAppState().idQuiz,
                                  ),
                                ),
                                builder: (context, snapshot) {
                                  // Customize what your widget looks like when it's loading.
                                  if (!snapshot.hasData) {
                                    return Center(
                                      child: SizedBox(
                                        width: 50.0,
                                        height: 50.0,
                                        child: CircularProgressIndicator(
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                            FlutterFlowTheme.of(context)
                                                .primary,
                                          ),
                                        ),
                                      ),
                                    );
                                  }
                                  List<QuestionRow> textQuestionRowList =
                                      snapshot.data!;
                                  return Text(
                                    valueOrDefault<String>(
                                      textQuestionRowList[_model.numQuestion]
                                          .question,
                                      'a',
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .displaySmall
                                        .override(
                                          fontFamily: 'Mina',
                                          fontSize: 20.0,
                                          letterSpacing: 0.0,
                                        ),
                                  ).animateOnPageLoad(animationsMap[
                                      'textOnPageLoadAnimation']!);
                                },
                              ),
                            ),
                            Wrap(
                              spacing: 0.0,
                              runSpacing: 0.0,
                              alignment: WrapAlignment.start,
                              crossAxisAlignment: WrapCrossAlignment.start,
                              direction: Axis.horizontal,
                              runAlignment: WrapAlignment.center,
                              verticalDirection: VerticalDirection.down,
                              clipBehavior: Clip.none,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      16.0, 12.0, 16.0, 0.0),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      FutureBuilder<List<QuestionRow>>(
                                        future: QuestionTable().querySingleRow(
                                          queryFn: (q) => q
                                              .eq(
                                                'quizz',
                                                FFAppState().idQuiz,
                                              )
                                              .eq(
                                                'question',
                                                quizPage1QuestionRowList[
                                                        _model.numQuestion]
                                                    .question,
                                              ),
                                        ),
                                        builder: (context, snapshot) {
                                          // Customize what your widget looks like when it's loading.
                                          if (!snapshot.hasData) {
                                            return Center(
                                              child: SizedBox(
                                                width: 50.0,
                                                height: 50.0,
                                                child:
                                                    CircularProgressIndicator(
                                                  valueColor:
                                                      AlwaysStoppedAnimation<
                                                          Color>(
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                  ),
                                                ),
                                              ),
                                            );
                                          }
                                          List<QuestionRow>
                                              radioButtonQuestionRowList =
                                              snapshot.data!;
                                          final radioButtonQuestionRow =
                                              radioButtonQuestionRowList
                                                      .isNotEmpty
                                                  ? radioButtonQuestionRowList
                                                      .first
                                                  : null;
                                          return FlutterFlowRadioButton(
                                            options: radioButtonQuestionRow!
                                                .ans1
                                                .toList(),
                                            onChanged: (val) => setState(() {}),
                                            controller: _model
                                                    .radioButtonValueController ??=
                                                FormFieldController<String>(
                                                    null),
                                            optionHeight: 32.0,
                                            textStyle:
                                                FlutterFlowTheme.of(context)
                                                    .labelMedium
                                                    .override(
                                                      fontFamily: 'Exo',
                                                      letterSpacing: 0.0,
                                                    ),
                                            selectedTextStyle:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .override(
                                                      fontFamily:
                                                          'Noto Sans JP',
                                                      letterSpacing: 0.0,
                                                    ),
                                            buttonPosition:
                                                RadioButtonPosition.left,
                                            direction: Axis.vertical,
                                            radioButtonColor: Color(0xFF93B05F),
                                            inactiveRadioButtonColor:
                                                FlutterFlowTheme.of(context)
                                                    .secondaryText,
                                            toggleable: false,
                                            horizontalAlignment:
                                                WrapAlignment.start,
                                            verticalAlignment:
                                                WrapCrossAlignment.start,
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 32.0, 0.0, 32.0),
                          child: FFButtonWidget(
                            onPressed: () async {
                              if (!(_model.numQuestion < 2)) {
                                if ((quizPage1QuestionRowList[
                                            _model.numQuestion]
                                        .answer!) ==
                                    (_model.radioButtonValue!)) {
                                  setState(() {
                                    _model.numAciertos =
                                        _model.numAciertos! + 1;
                                  });
                                }
                                if ((int var2) {
                                  return var2 >= (3 / 2);
                                }(_model.numAciertos!)) {
                                  context.pushNamed(
                                    'celebrate_page',
                                    extra: <String, dynamic>{
                                      kTransitionInfoKey: TransitionInfo(
                                        hasTransition: true,
                                        transitionType:
                                            PageTransitionType.leftToRight,
                                        duration: Duration(milliseconds: 700),
                                      ),
                                    },
                                  );
                                } else {
                                  context.pushNamed(
                                    'failute_page',
                                    extra: <String, dynamic>{
                                      kTransitionInfoKey: TransitionInfo(
                                        hasTransition: true,
                                        transitionType:
                                            PageTransitionType.leftToRight,
                                        duration: Duration(milliseconds: 700),
                                      ),
                                    },
                                  );
                                }

                                return;
                              }
                              if ((quizPage1QuestionRowList[_model.numQuestion]
                                      .answer!) ==
                                  (_model.radioButtonValue!)) {
                                setState(() {
                                  _model.isCorrect = true;
                                  _model.numAciertos = _model.numAciertos! + 1;
                                });
                                _model.timer1Controller.onResetTimer();

                                _model.timer1Controller.onStartTimer();
                              } else {
                                setState(() {
                                  _model.isNotCorrect = true;
                                });
                                _model.timer2Controller.onResetTimer();

                                _model.timer2Controller.onStartTimer();
                              }

                              setState(() {
                                _model.numQuestion = _model.numQuestion + 1;
                              });
                              await Future.delayed(
                                  const Duration(milliseconds: 5000));
                              setState(() {
                                _model.isCorrect = false;
                                _model.isNotCorrect = false;
                              });
                            },
                            text: _model.numQuestion.toString() == 2
                                ? 'Terminar quiz'
                                : 'Siguiente pregunta',
                            options: FFButtonOptions(
                              width: 300.0,
                              height: 50.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: Color(0xFF3D3328),
                              textStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    fontFamily: 'Exo',
                                    color: Colors.white,
                                    letterSpacing: 0.0,
                                  ),
                              elevation: 3.0,
                              borderSide: BorderSide(
                                color: Colors.transparent,
                                width: 1.0,
                              ),
                              borderRadius: BorderRadius.circular(40.0),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                if (_model.isCorrect)
                  Container(
                    width: 529.0,
                    height: 762.0,
                    decoration: BoxDecoration(
                      color: FlutterFlowTheme.of(context).primaryBackground,
                    ),
                    child: Stack(
                      children: [
                        Align(
                          alignment: AlignmentDirectional(0.0, -0.42),
                          child: Lottie.asset(
                            'assets/lottie_animations/Orange_0.json',
                            width: 456.0,
                            height: 327.0,
                            fit: BoxFit.cover,
                            animate: true,
                          ),
                        ),
                        Align(
                          alignment: AlignmentDirectional(-0.05, 0.24),
                          child: Text(
                            '¡Bien hecho!',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Exo',
                                  fontSize: 56.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                        Align(
                          alignment: AlignmentDirectional(-0.05, 0.79),
                          child: CircularPercentIndicator(
                            percent: (int var1) {
                              return var1 <= 0
                                  ? 1.0
                                  : (1.0 - ((var1 as double) / 5000.0));
                            }(_model.timer1Milliseconds),
                            radius: 60.0,
                            lineWidth: 20.0,
                            animation: true,
                            animateFromLastPercent: true,
                            progressColor: FlutterFlowTheme.of(context).primary,
                            backgroundColor:
                                FlutterFlowTheme.of(context).accent4,
                          ),
                        ),
                        Align(
                          alignment: AlignmentDirectional(-0.04, 0.72),
                          child: FlutterFlowTimer(
                            initialTime: _model.timer1InitialTimeMs,
                            getDisplayTime: (value) =>
                                StopWatchTimer.getDisplayTime(
                              value,
                              hours: false,
                              minute: false,
                              milliSecond: false,
                            ),
                            controller: _model.timer1Controller,
                            updateStateInterval: Duration(milliseconds: 1000),
                            onChanged: (value, displayTime, shouldUpdate) {
                              _model.timer1Milliseconds = value;
                              _model.timer1Value = displayTime;
                              if (shouldUpdate) setState(() {});
                            },
                            textAlign: TextAlign.start,
                            style: FlutterFlowTheme.of(context)
                                .headlineSmall
                                .override(
                                  fontFamily: 'Mina',
                                  fontSize: 36.0,
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ],
                    ),
                  ),
                if (_model.isNotCorrect)
                  Align(
                    alignment: AlignmentDirectional(0.0, 0.0),
                    child: Container(
                      width: 634.0,
                      height: 812.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).primaryBackground,
                      ),
                      child: Stack(
                        children: [
                          Align(
                            alignment: AlignmentDirectional(-6.67, -0.47),
                            child: Lottie.asset(
                              'assets/lottie_animations/UPV_0.json',
                              width: 379.0,
                              height: 477.0,
                              fit: BoxFit.cover,
                              animate: true,
                            ),
                          ),
                          Align(
                            alignment: AlignmentDirectional(0.0, 0.39),
                            child: Text(
                              'Respuesta incorrecta',
                              textAlign: TextAlign.center,
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Exo',
                                    fontSize: 56.0,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                          Align(
                            alignment: AlignmentDirectional(-0.06, 0.84),
                            child: CircularPercentIndicator(
                              percent: (int var1) {
                                return var1 <= 0
                                    ? 1.0
                                    : (1.0 - ((var1 as double) / 5000.0));
                              }(_model.timer2Milliseconds),
                              radius: 60.0,
                              lineWidth: 20.0,
                              animation: true,
                              animateFromLastPercent: true,
                              progressColor:
                                  FlutterFlowTheme.of(context).primary,
                              backgroundColor:
                                  FlutterFlowTheme.of(context).accent4,
                            ),
                          ),
                          Align(
                            alignment: AlignmentDirectional(-0.04, 0.76),
                            child: FlutterFlowTimer(
                              initialTime: _model.timer2InitialTimeMs,
                              getDisplayTime: (value) =>
                                  StopWatchTimer.getDisplayTime(
                                value,
                                hours: false,
                                minute: false,
                                milliSecond: false,
                              ),
                              controller: _model.timer2Controller,
                              updateStateInterval: Duration(milliseconds: 1000),
                              onChanged: (value, displayTime, shouldUpdate) {
                                _model.timer2Milliseconds = value;
                                _model.timer2Value = displayTime;
                                if (shouldUpdate) setState(() {});
                              },
                              textAlign: TextAlign.start,
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Mina',
                                    fontSize: 36.0,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}
