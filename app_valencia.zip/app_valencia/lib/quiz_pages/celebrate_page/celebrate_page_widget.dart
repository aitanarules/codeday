import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'celebrate_page_model.dart';
export 'celebrate_page_model.dart';

class CelebratePageWidget extends StatefulWidget {
  const CelebratePageWidget({super.key});

  @override
  State<CelebratePageWidget> createState() => _CelebratePageWidgetState();
}

class _CelebratePageWidgetState extends State<CelebratePageWidget>
    with TickerProviderStateMixin {
  late CelebratePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CelebratePageModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.filaStop = await StopTable().queryRows(
        queryFn: (q) => q.eq(
          'id',
          FFAppState().idStop,
        ),
      );
      await UserHasRewardTable().insert({
        'id_user': FFAppState().idUser,
        'id_reward': _model.filaStop?.first?.reward,
        'type': 'emblem',
      });
      setState(() {
        FFAppState().idReward = _model.filaStop!.first.reward!;
        FFAppState().logroObtenido = true;
      });
      _model.filaReward = await RewardTable().queryRows(
        queryFn: (q) => q.eq(
          'id',
          FFAppState().idReward,
        ),
      );
      setState(() {
        _model.image = _model.filaReward?.first?.image;
      });
      _model.total = await StopTable().queryRows(
        queryFn: (q) => q.eq(
          'town',
          FFAppState().idTown,
        ),
      );
      _model.actuales = await UserHasRewardTable().queryRows(
        queryFn: (q) => q
            .eq(
              'id_user',
              FFAppState().idUser,
            )
            .eq(
              'type',
              'emblem',
            )
            .eq(
              'town_id',
              FFAppState().idTown,
            ),
      );
      setState(() {
        _model.numTotal = _model.total?.length;
        _model.numActual = _model.actuales?.length;
      });
    });

    animationsMap.addAll({
      'textOnPageLoadAnimation': AnimationInfo(
        loop: true,
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          ShimmerEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 2000.0.ms,
            color: FlutterFlowTheme.of(context).primary,
            angle: 0.524,
          ),
        ],
      ),
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return FutureBuilder<List<StopRow>>(
      future: StopTable().querySingleRow(
        queryFn: (q) => q.eq(
          'id',
          FFAppState().idStop,
        ),
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).alternate,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        List<StopRow> celebratePageStopRowList = snapshot.data!;
        final celebratePageStopRow = celebratePageStopRowList.isNotEmpty
            ? celebratePageStopRowList.first
            : null;
        return GestureDetector(
          onTap: () => _model.unfocusNode.canRequestFocus
              ? FocusScope.of(context).requestFocus(_model.unfocusNode)
              : FocusScope.of(context).unfocus(),
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).alternate,
            body: Align(
              alignment: AlignmentDirectional(0.0, 0.0),
              child: Stack(
                alignment: AlignmentDirectional(0.0, 0.0),
                children: [
                  Align(
                    alignment: AlignmentDirectional(-0.08, -0.66),
                    child: Text(
                      '¡Felicidades!',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'bakso',
                            fontSize: 56.0,
                            letterSpacing: 0.0,
                            useGoogleFonts: false,
                          ),
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional(0.02, 0.53),
                    child: Text(
                      '¡Has completado esta parada!',
                      textAlign: TextAlign.center,
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'bakso',
                            fontSize: 32.0,
                            letterSpacing: 0.0,
                            useGoogleFonts: false,
                          ),
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional(0.01, 0.77),
                    child: Text(
                      '${_model.numActual?.toString()} / ${_model.numTotal?.toString()}',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'bakso',
                            color: FlutterFlowTheme.of(context).primaryText,
                            fontSize: 42.0,
                            letterSpacing: 0.0,
                            useGoogleFonts: false,
                          ),
                    ).animateOnPageLoad(
                        animationsMap['textOnPageLoadAnimation']!),
                  ),
                  Align(
                    alignment: AlignmentDirectional(0.0, 0.0),
                    child: Lottie.asset(
                      'assets/lottie_animations/orange_celebration_2.json',
                      width: 406.0,
                      height: 926.0,
                      fit: BoxFit.fill,
                      animate: true,
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional(0.95, -0.9),
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 16.0, 0.0),
                      child: FlutterFlowIconButton(
                        borderColor: Colors.transparent,
                        borderRadius: 30.0,
                        borderWidth: 1.0,
                        buttonSize: 50.0,
                        fillColor:
                            FlutterFlowTheme.of(context).primaryBackground,
                        icon: Icon(
                          Icons.close_rounded,
                          color: FlutterFlowTheme.of(context).secondaryText,
                          size: 30.0,
                        ),
                        onPressed: () async {
                          context.goNamed(
                            'mapaMunicipio',
                            extra: <String, dynamic>{
                              kTransitionInfoKey: TransitionInfo(
                                hasTransition: true,
                                transitionType: PageTransitionType.fade,
                                duration: Duration(milliseconds: 700),
                              ),
                            },
                          );
                        },
                      ),
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional(0.02, 0.01),
                    child: Container(
                      width: 250.0,
                      height: 250.0,
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                      ),
                      child: Image.network(
                        _model.image!,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
