import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'celebrate_page_widget.dart' show CelebratePageWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';

class CelebratePageModel extends FlutterFlowModel<CelebratePageWidget> {
  ///  Local state fields for this page.

  String? image;

  int? numTotal;

  int? numActual;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Backend Call - Query Rows] action in celebrate_page widget.
  List<StopRow>? filaStop;
  // Stores action output result for [Backend Call - Query Rows] action in celebrate_page widget.
  List<RewardRow>? filaReward;
  // Stores action output result for [Backend Call - Query Rows] action in celebrate_page widget.
  List<StopRow>? total;
  // Stores action output result for [Backend Call - Query Rows] action in celebrate_page widget.
  List<UserHasRewardRow>? actuales;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
