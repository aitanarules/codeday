// Automatic FlutterFlow imports
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:app_valencia/definitive_user_pages/mapa2_d/mapa2_d_widget.dart';

import '/flutter_flow/flutter_flow_widgets.dart';

import 'package:flutter/scheduler.dart';
import 'dart:developer';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' as ll;
import 'package:flutter_map_animations/flutter_map_animations.dart';
import 'package:flutter_map_cancellable_tile_provider/flutter_map_cancellable_tile_provider.dart';
import 'package:flutter_map_marker_cluster/flutter_map_marker_cluster.dart';
import '../../definitive_user_pages/mapa2_d/mapa2_d_model.dart' as home_page;

const MAPBOX_ACCESS_TOKEN =
    'pk.eyJ1IjoiZWR1YXJkbzExMTE4IiwiYSI6ImNsdW1saGhybTAweDMyam8xcXE2b3Y0OWkifQ.tCEyrYgMwdNPKbCojX_r4A';
final myPosition = ll.LatLng(39.45, -0.78);
LatLngBounds myBounds =
    LatLngBounds(ll.LatLng(41.0, 0.9), ll.LatLng(37.6, -2.0));
bool mostrarBoton = false;
String name = "";
double? size = 0.0;
double? sizeText = 0.0;
bool camLock = false;
double zoom1 = 0.0;
String id_mapa = "";

class DynamicMap extends StatefulWidget {
  const DynamicMap({
    super.key,
    this.width,
    this.height,
    this.townLatList,
    this.townLongList,
    this.townNameList,
    this.test,
    this.testBoolean,
  });

  final double? width;
  final double? height;
  final List<double>? townLatList;
  final List<double>? townLongList;
  final List<String>? townNameList;
  final List<TownRow>? test;
  final bool? testBoolean;

  @override
  State<DynamicMap> createState() => _MyDynamicMapState();
}

class _MyDynamicMapState extends State<DynamicMap>
    with TickerProviderStateMixin {
  static const _useTransformerId = 'useTransformerId';
  bool primeraVez = true;
  final markers = ValueNotifier<List<AnimatedMarker>>([]);
  final center = const ll.LatLng(39.45, -0.78);
  final markers2 = ValueNotifier<List<Marker>>([]);
  late home_page.Mapa2DModel _model;
  bool _useTransformer = true;
  double zoomLevel = 1.0;
  //int _lastMovedToMarkerIndex = -1;

  final PopupController _popupController = PopupController();
  late final _animatedMapController = AnimatedMapController(vsync: this);

  @override
  void dispose() {
    markers.dispose();
    markers2.dispose();
    _animatedMapController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    _model = createModel(context, () => Mapa2DModel());
    super.initState();
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    if (FFAppState().logroObtenido) {
      id_mapa =
          'https://api.mapbox.com/styles/v1/eduardo11118/clw8alfzv01md01qu1dlugxmr/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiZWR1YXJkbzExMTE4IiwiYSI6ImNsdHN2ODd2MzB3MzUyam8zOWZhdzBsMjYifQ.FhUKou2yT-7Gu9D7BBmtOg';
    } else {
      id_mapa =
          'https://api.mapbox.com/styles/v1/eduardo11118/clw8b8dvx002i01pg0rdg6g9y/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiZWR1YXJkbzExMTE4IiwiYSI6ImNsdHN2ODd2MzB3MzUyam8zOWZhdzBsMjYifQ.FhUKou2yT-7Gu9D7BBmtOg';
    }
    print("hola aqui tienes que revisar");
    if (primeraVez) {
      addMunicipios(
          widget.townLatList!, widget.townLongList!, widget.townNameList!);
      primeraVez = false;
    }
    //zoom1 = _animatedMapController.mapController.camera.zoom;

    /*if (camLock) {
      print('lokeada');
      myBounds = LatLngBounds(ll.LatLng(39.45, -0.78), ll.LatLng(39.45, -0.78));
    } else {
      print('libre');
      myBounds = LatLngBounds(ll.LatLng(41.0, 0.9), ll.LatLng(37.6, -2.0));
    }*/

    if (zoomLevel >= 9) {
      // Si el zoom es 11 o mayor, actualiza el widget
      return buildZoomedInUI(); // Método que construye la interfaz de usuario para el zoom ampliado
    } else {
      // Si el zoom es menor que 11, construye la interfaz de usuario normal
      return buildNormalUI();
    }
  }

  Widget buildNormalUI() {
    camLock = false;
    print("zoom normal");
    //print(_model.isDisable!);
    // Lógica para construir la interfaz de usuario normal
    return Scaffold(
      body: Stack(
        children: [
          PopupScope(
            popupController: _popupController,
            child: ValueListenableBuilder<List<Marker>>(
              valueListenable: markers2,
              builder: (context, markers2, _) {
                return FlutterMap(
                  mapController: _animatedMapController.mapController,
                  options: MapOptions(
                    initialCenter: myPosition,
                    minZoom: 5,
                    maxZoom: 12,
                    initialZoom: 8.5,
                    interactionOptions:
                        camLock ? InteractionOptions(flags: 0) : null,
                    cameraConstraint:
                        CameraConstraint.contain(bounds: myBounds),
                    onTap: (_, point) {
                      // _addMarker(point);
                      _popupController.hideAllPopups();
                    },
                    onMapEvent: (mapEve) {
                      (!camLock & FFAppState().showDetallesButtom)
                          ? setState(() {
                              FFAppState().showDetallesButtom = false;
                              print('muestro boton');
                            })
                          : null;
                      print(FFAppState().showDetallesButtom.toString());
                      (camLock & !FFAppState().showDetallesButtom)
                          ? setState(() {
                              FFAppState().showDetallesButtom = true;
                              print('muestro boton');
                            })
                          : null;
                      print(FFAppState().showDetallesButtom.toString());
                      if (mapEve.camera.zoom < 10) {
                        size = 0.0;
                        sizeText = 0.0;
                        zoom1 = mapEve.camera.zoom;
                        updateZoom(mapEve.camera.zoom);
                        print('He evento a:' + mapEve.camera.zoom.toString());
                      } else {
                        size = 25;
                        sizeText = 10.0;
                        zoom1 = mapEve.camera.zoom;
                        updateZoom(mapEve.camera.zoom);
                        print('He evento de:' + mapEve.camera.zoom.toString());
                      }
                    },
                  ),
                  children: [
                    TileLayer(
                      urlTemplate:
                          'https://api.mapbox.com/styles/v1/eduardo11118/clw8alfzv01md01qu1dlugxmr/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiZWR1YXJkbzExMTE4IiwiYSI6ImNsdHN2ODd2MzB3MzUyam8zOWZhdzBsMjYifQ.FhUKou2yT-7Gu9D7BBmtOg',
                      tileUpdateTransformer: _animatedMoveTileUpdateTransformer,
                      tileProvider: CancellableNetworkTileProvider(),
                    ),
                    MarkerClusterLayerWidget(
                      options: MarkerClusterLayerOptions(
                        //spiderfyCluster: false,
                        spiderfyCircleRadius: 80,
                        spiderfySpiralDistanceMultiplier: 2,
                        circleSpiralSwitchover: 12,
                        maxClusterRadius: 120,
                        rotate: true,
                        size: const Size(40, 40),
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(50),
                        maxZoom: 14.0,
                        markers: markers2,
                        polygonOptions: const PolygonOptions(
                          borderColor: Colors.blueAccent,
                          color: Colors.black12,
                          borderStrokeWidth: 3,
                        ),
                        builder: (context, markers2) {
                          return Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.blue,
                            ),
                            child: Center(
                              child: Text(
                                markers2.length.toString(),
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    if (FFAppState().showDetallesButtom)
                      Align(
                        alignment: AlignmentDirectional(0, 1),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 60),
                          child: Container(
                            width: 283,
                            height: 104,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).primary,
                              borderRadius: BorderRadius.circular(15),
                              shape: BoxShape.rectangle,
                            ),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: _model.isDisable!
                                  ? null
                                  : () {
                                      //mostrarOcultarBoton();
                                      context.pushNamed('mapaMunicipio');
                                    },
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0, 8, 0, 8),
                                    child: Text(
                                      valueOrDefault<String>(
                                        _model.munName,
                                        'Nombre',
                                      ),
                                      style: FlutterFlowTheme.of(context)
                                          .headlineLarge
                                          .override(
                                            fontFamily: 'Mina',
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                            letterSpacing: 0,
                                          ),
                                    ),
                                  ),
                                  FFButtonWidget(
                                    onPressed: _model.isDisable!
                                        ? null
                                        : () async {
                                            //mostrarOcultarBoton();
                                            _model.filaActualMunicipio =
                                                await TownTable().queryRows(
                                              queryFn: (q) => q.eq(
                                                'name',
                                                _model.munName,
                                              ),
                                            );
                                            setState(() {
                                              FFAppState().idTown = _model
                                                  .filaActualMunicipio!
                                                  .first
                                                  .id;
                                            });

                                            context.pushNamed(
                                                'descripcionMunicipio');

                                            setState(() {});
                                          },
                                    text: 'Saber más',
                                    options: FFButtonOptions(
                                      height: 30,
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          24, 0, 24, 0),
                                      iconPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              0, 0, 0, 0),
                                      color:
                                          FlutterFlowTheme.of(context).tertiary,
                                      textStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Exo',
                                            color: Colors.white,
                                            fontSize: 14,
                                            letterSpacing: 0,
                                            fontWeight: FontWeight.w300,
                                          ),
                                      elevation: 3,
                                      borderSide: BorderSide(
                                        color: Colors.transparent,
                                        width: 1,
                                      ),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    if (FFAppState().showDetallesButtom)
                      Align(
                        alignment: AlignmentDirectional(-0.87, -0.8),
                        child: FloatingActionButton(
                          backgroundColor: Colors.transparent,
                          elevation: 0,
                          onPressed: () {
                            //markers.value = [];
                            camLock = false;
                            _animatedMapController.animateTo(
                              dest: center,
                              rotation: 0,
                              customId:
                                  _useTransformer ? _useTransformerId : null,
                            );
                            _animatedMapController.centerOnPoint(myPosition,
                                zoom: 8.5);
                            //mostrarOcultarBoton();

                            FFAppState().update(() {
                              FFAppState().idUser = FFAppState().idUser;
                            });

                            print('presionaste boton atras');
                          },
                          tooltip: 'Volver al mapa',
                          child: Icon(
                            Icons.west,
                            color: FlutterFlowTheme.of(context).secondaryText,
                            size: 40,
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget buildZoomedInUI() {
    print("zoom de cerca");
    //print(_model.isDisable!);
    // Lógica para construir la interfaz de usuario ampliada
    return Scaffold(
      body: Stack(
        children: [
          PopupScope(
            popupController: _popupController,
            child: ValueListenableBuilder<List<Marker>>(
              valueListenable: markers2,
              builder: (context, markers2, _) {
                return FlutterMap(
                  mapController: _animatedMapController.mapController,
                  options: MapOptions(
                    initialCenter: myPosition,
                    minZoom: 5,
                    maxZoom: 14,
                    initialZoom: 8.5,
                    interactionOptions:
                        camLock ? InteractionOptions(flags: 0) : null,
                    cameraConstraint:
                        CameraConstraint.contain(bounds: myBounds),
                    onTap: (_, point) {
                      // _addMarker(point);
                      _popupController.hideAllPopups();
                    },
                    onMapEvent: (mapEve) {
                      (!camLock & FFAppState().showDetallesButtom)
                          ? setState(() {
                              FFAppState().showDetallesButtom = false;
                              print('muestro boton');
                            })
                          : null;
                      print(FFAppState().showDetallesButtom.toString());
                      (camLock & !FFAppState().showDetallesButtom)
                          ? setState(() {
                              FFAppState().showDetallesButtom = true;
                              print('muestro boton');
                            })
                          : null;
                      print(FFAppState().showDetallesButtom.toString());
                      if (mapEve.camera.zoom < 10) {
                        size = 0.0;
                        sizeText = 0.0;
                        zoom1 = mapEve.camera.zoom;
                        updateZoom(mapEve.camera.zoom);
                        print('He cambiado de evento a:' +
                            mapEve.camera.zoom.toString());
                      } else {
                        size = 25;
                        sizeText = 10.0;
                        zoom1 = mapEve.camera.zoom;
                        updateZoom(mapEve.camera.zoom);
                        print('He cambiado de evento de:' +
                            mapEve.camera.zoom.toString());
                      }
                    },
                  ),
                  children: [
                    TileLayer(
                      urlTemplate:
                          'https://api.mapbox.com/styles/v1/eduardo11118/clvzqwdll02g901qu2csr52qy/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiZWR1YXJkbzExMTE4IiwiYSI6ImNsdHN2ODd2MzB3MzUyam8zOWZhdzBsMjYifQ.FhUKou2yT-7Gu9D7BBmtOg',
                      tileUpdateTransformer: _animatedMoveTileUpdateTransformer,
                      tileProvider: CancellableNetworkTileProvider(),
                    ),
                    MarkerClusterLayerWidget(
                      options: MarkerClusterLayerOptions(
                        //spiderfyCluster: false,
                        spiderfyCircleRadius: 80,
                        spiderfySpiralDistanceMultiplier: 2,
                        circleSpiralSwitchover: 12,
                        maxClusterRadius: 10,
                        rotate: true,
                        size: const Size(40, 40),
                        alignment: Alignment.center,
                        padding: const EdgeInsets.all(50),
                        maxZoom: 14.0,
                        markers: markers2,
                        disableClusteringAtZoom: 11,
                        polygonOptions: const PolygonOptions(
                          borderColor: Colors.blueAccent,
                          color: Colors.black12,
                          borderStrokeWidth: 3,
                        ),
                        builder: (context, markers2) {
                          return Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.blue,
                            ),
                            child: Center(
                              child: Text(
                                markers2.length.toString(),
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    if (FFAppState().showDetallesButtom)
                      Align(
                        alignment: AlignmentDirectional(0, 1),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 60),
                          child: Container(
                            width: 283,
                            height: 104,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).primary,
                              borderRadius: BorderRadius.circular(15),
                              shape: BoxShape.rectangle,
                            ),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: _model.isDisable!
                                  ? null
                                  : () async {
                                      //mostrarOcultarBoton();
                                      context.pushNamed('mapaMunicipio');
                                    },
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0, 8, 0, 8),
                                    child: Text(
                                      valueOrDefault<String>(
                                        _model.munName,
                                        'Nombre',
                                      ),
                                      style: FlutterFlowTheme.of(context)
                                          .headlineLarge
                                          .override(
                                            fontFamily: 'Mina',
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                            letterSpacing: 0,
                                          ),
                                    ),
                                  ),
                                  FFButtonWidget(
                                    onPressed: _model.isDisable!
                                        ? null
                                        : () async {
                                            //mostrarOcultarBoton();
                                            _model.filaActualMunicipio =
                                                await TownTable().queryRows(
                                              queryFn: (q) => q.eq(
                                                'name',
                                                _model.munName,
                                              ),
                                            );
                                            setState(() {
                                              FFAppState().idTown = _model
                                                  .filaActualMunicipio!
                                                  .first
                                                  .id;
                                            });

                                            context.pushNamed(
                                                'descripcionMunicipio');
                                          },
                                    text: 'Saber más',
                                    options: FFButtonOptions(
                                      height: 30,
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          24, 0, 24, 0),
                                      iconPadding:
                                          EdgeInsetsDirectional.fromSTEB(
                                              0, 0, 0, 0),
                                      color:
                                          FlutterFlowTheme.of(context).tertiary,
                                      textStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Exo',
                                            color: Colors.white,
                                            fontSize: 14,
                                            letterSpacing: 0,
                                            fontWeight: FontWeight.w300,
                                          ),
                                      elevation: 3,
                                      borderSide: BorderSide(
                                        color: Colors.transparent,
                                        width: 1,
                                      ),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    if (FFAppState().showDetallesButtom)
                      Align(
                        alignment: AlignmentDirectional(-0.87, -0.8),
                        child: FloatingActionButton(
                          backgroundColor: Colors.transparent,
                          elevation: 0,
                          onPressed: () {
                            //mostrarOcultarBoton();
                            //markers.value = [];
                            camLock = false;
                            _animatedMapController.animateTo(
                              dest: center,
                              rotation: 0,
                              customId:
                                  _useTransformer ? _useTransformerId : null,
                            );
                            _animatedMapController.centerOnPoint(myPosition,
                                zoom: 8.5);
                            //mostrarOcultarBoton();
                            Future.delayed(Duration(seconds: 1)).then((_) {
                              FFAppState().update(() {
                                FFAppState().idUser = FFAppState().idUser;
                              });
                              print('La instrucción ha terminado');
                            });
                            print('presionaste boton atras');
                          },
                          tooltip: 'Volver al mapa',
                          child: Icon(
                            Icons.west,
                            color: FlutterFlowTheme.of(context).secondaryText,
                            size: 40,
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void updateZoom(double newZoom) {
    setState(() {
      zoomLevel = newZoom;
    });
  }

  /*floatingActionButton: SeparatedColumn(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        separator: const SizedBox(height: 8),
        children: [
          FloatingActionButton(
            onPressed: () {
              //markers.value = [];
              camLock = false;
              _animatedMapController.animateTo(
                dest: center,
                rotation: 0,
                customId: _useTransformer ? _useTransformerId : null,
              );
              _animatedMapController.centerOnPoint(myPosition, zoom: 8.5);
              mostrarOcultarBoton();
              print('presionaste boton atras');
            },
            tooltip: 'Clear modifications',
            child: const Icon(Icons.clear_all),
          ),
          FloatingActionButton(
            onPressed: () => _animatedMapController.animatedZoomIn(
              customId: _useTransformer ? _useTransformerId : null,
            ),
            tooltip: 'Zoom in',
            child: const Icon(Icons.zoom_in),
          ),
          FloatingActionButton(
            onPressed: () => _animatedMapController.animatedZoomOut(
              customId: _useTransformer ? _useTransformerId : null,
            ),
            tooltip: 'Zoom out',
            child: const Icon(Icons.zoom_out),
          ),
        ],
      ),*/

  void _addMarker2(ll.LatLng point, name1) {
    markers2.value = List.from(markers2.value)
      ..add(
        MyMarker2(
          point: point,
          name: name1,
          onTap: () async {
            //camLock ? null : await mostrarOcultarBoton();
            camLock = true;
            changeName(name1);
            _model.munName = name1;
            camLock = true;
            ll.LatLng point11 =
                ll.LatLng(point.latitude - 0.04, point.longitude);
            _animatedMapController.centerOnPoint(point11, zoom: 12.0);

            print(_model.rowListNotNull.toString());

            _model.rowList = await TownTable().queryRows(
              queryFn: (q) => q.not(
                'image',
                'is',
                null,
              ),
            );
            setState(() {
              _model.rowListNotNull = _model.rowList!.toList().cast<TownRow>();
            });
            print(_model.rowListNotNull.toString());
            if (_model.rowListNotNull
                .map((e) => e.name)
                .withoutNulls
                .toList()
                .contains((name1))) {
              setState(() {
                print("Será true");
                _model.isDisable = false;
              });
            } else {
              setState(() {
                print("Será false");
                _model.isDisable = true;
              });
            }
          },
        ),
      );
  }

  Future<void> mostrarOcultarBoton() async {
    setState(() {
      //mostrarBoton = !mostrarBoton;
      FFAppState().showDetallesButtom = !FFAppState().showDetallesButtom;
      print('muestro boton');
    });
  }

  void changeName(String newName) {
    setState(() {
      name = newName;
      print(name);
    });
  }

  void addMunicipios(
      List<double>? listLat, List<double>? listLong, List<String>? listName) {
    /*//Añadimos Xativa
    const point = ll.LatLng(38.988, -0.52);
    _addMarker2(point, "Xàtiva");

    //Añadimos Paterna
    const point2 = ll.LatLng(39.525, -0.46);
    _addMarker2(point2, "Paterna");

    //Añadimos Puig
    const point3 = ll.LatLng(39.5887818, -0.306);
    _addMarker2(point3, "Puig");
    */
    ll.LatLng point;
    for (int i = 0; i < listLong!.length; i++) {
      if (listName!.elementAt(i).contains('València') ||
          listName!.elementAt(i).contains('Valencia')) {
      } else {
        point = ll.LatLng(listLat!.elementAt(i), listLong.elementAt(i));
        _addMarker2(point, listName!.elementAt(i));
      }
    }
  }
}

class MyMarker2 extends Marker {
  MyMarker2({
    required ll.LatLng point,
    required name,
    size,
    sizeText,
    VoidCallback? onTap,
  }) : super(
            width: markerSize * 10,
            height: markerSize * 5,
            point: point,
            child: GestureDetector(
              onTap: onTap,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.add_location_rounded,
                    color: Colors.black,
                    size: size,
                  ),
                  Text(
                    name,
                    style: TextStyle(
                      fontSize: sizeText,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ));
  static const markerSize = 10.0;
}

class SeparatedColumn extends StatelessWidget {
  const SeparatedColumn({
    super.key,
    required this.separator,
    this.children = const [],
    this.mainAxisSize = MainAxisSize.max,
    this.crossAxisAlignment = CrossAxisAlignment.start,
  });

  final Widget separator;
  final List<Widget> children;
  final MainAxisSize mainAxisSize;
  final CrossAxisAlignment crossAxisAlignment;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: mainAxisSize,
      crossAxisAlignment: crossAxisAlignment,
      children: [
        ..._buildChildren(),
      ],
    );
  }

  Iterable<Widget> _buildChildren() sync* {
    for (var i = 0; i < children.length; i++) {
      yield children[i];
      if (i < children.length - 1) yield separator;
    }
  }
}

/// Inspired by the contribution of [rorystephenson](https://github.com/fleaflet/flutter_map/pull/1475/files#diff-b663bf9f32e20dbe004bd1b58a53408aa4d0c28bcc29940156beb3f34e364556)
final _animatedMoveTileUpdateTransformer = TileUpdateTransformer.fromHandlers(
  handleData: (updateEvent, sink) {
    final id = AnimationId.fromMapEvent(updateEvent.mapEvent);

    if (id == null) return sink.add(updateEvent);
    if (id.customId != _MyDynamicMapState._useTransformerId) {
      if (id.moveId == AnimatedMoveId.started) {
        debugPrint('TileUpdateTransformer disabled, using default behaviour.');
      }
      return sink.add(updateEvent);
    }

    switch (id.moveId) {
      case AnimatedMoveId.started:
        debugPrint('Loading tiles at animation destination.');
        sink.add(
          updateEvent.loadOnly(
            loadCenterOverride: id.destLocation,
            loadZoomOverride: id.destZoom,
          ),
        );
        break;
      case AnimatedMoveId.inProgress:
        // Do not prune or load during movement.
        break;
      case AnimatedMoveId.finished:
        debugPrint('Pruning tiles after animated movement.');
        sink.add(updateEvent.pruneOnly());
        break;
    }
  },
);
