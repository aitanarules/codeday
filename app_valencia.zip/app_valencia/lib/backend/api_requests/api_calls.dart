import 'dart:convert';
import 'dart:typed_data';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class PruebaCall {
  static Future<ApiCallResponse> call({
    int? offset,
    int? limit = 10,
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Prueba',
      apiUrl:
          'https://appgchdaqxkcqudowisg.supabase.co/rest/v1/AVATAR?select=image',
      callType: ApiCallType.GET,
      headers: {
        'apikey':
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFwcGdjaGRhcXhrY3F1ZG93aXNnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTA1MjMwMTksImV4cCI6MjAyNjA5OTAxOX0.qAXomWWMZ2cRHrU-v1shsuXj1Uy160Rnjiw8UGUOL7Y',
        'Authorization':
            'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFwcGdjaGRhcXhrY3F1ZG93aXNnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTA1MjMwMTksImV4cCI6MjAyNjA5OTAxOX0.qAXomWWMZ2cRHrU-v1shsuXj1Uy160Rnjiw8UGUOL7Y',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list);
  } catch (_) {
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar);
  } catch (_) {
    return isList ? '[]' : '{}';
  }
}
