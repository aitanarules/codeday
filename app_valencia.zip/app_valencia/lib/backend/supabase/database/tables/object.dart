import '../database.dart';

class ObjectTable extends SupabaseTable<ObjectRow> {
  @override
  String get tableName => 'OBJECT';

  @override
  ObjectRow createRow(Map<String, dynamic> data) => ObjectRow(data);
}

class ObjectRow extends SupabaseDataRow {
  ObjectRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ObjectTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get reward => getField<String>('reward');
  set reward(String? value) => setField<String>('reward', value);
}
