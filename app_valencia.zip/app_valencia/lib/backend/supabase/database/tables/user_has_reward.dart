import '../database.dart';

class UserHasRewardTable extends SupabaseTable<UserHasRewardRow> {
  @override
  String get tableName => 'USER_HAS_REWARD';

  @override
  UserHasRewardRow createRow(Map<String, dynamic> data) =>
      UserHasRewardRow(data);
}

class UserHasRewardRow extends SupabaseDataRow {
  UserHasRewardRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => UserHasRewardTable();

  String get idUser => getField<String>('id_user')!;
  set idUser(String value) => setField<String>('id_user', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String get idReward => getField<String>('id_reward')!;
  set idReward(String value) => setField<String>('id_reward', value);

  String? get type => getField<String>('type');
  set type(String? value) => setField<String>('type', value);

  String? get townId => getField<String>('town_id');
  set townId(String? value) => setField<String>('town_id', value);

  double? get experience => getField<double>('experience');
  set experience(double? value) => setField<double>('experience', value);
}
