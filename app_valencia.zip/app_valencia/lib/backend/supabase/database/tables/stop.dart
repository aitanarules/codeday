import '../database.dart';

class StopTable extends SupabaseTable<StopRow> {
  @override
  String get tableName => 'STOP';

  @override
  StopRow createRow(Map<String, dynamic> data) => StopRow(data);
}

class StopRow extends SupabaseDataRow {
  StopRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => StopTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  String? get type => getField<String>('type');
  set type(String? value) => setField<String>('type', value);

  double? get latitude => getField<double>('latitude');
  set latitude(double? value) => setField<double>('latitude', value);

  double? get longitude => getField<double>('longitude');
  set longitude(double? value) => setField<double>('longitude', value);

  String? get quizz => getField<String>('quizz');
  set quizz(String? value) => setField<String>('quizz', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  String? get address => getField<String>('address');
  set address(String? value) => setField<String>('address', value);

  String? get reward => getField<String>('reward');
  set reward(String? value) => setField<String>('reward', value);

  String? get town => getField<String>('town');
  set town(String? value) => setField<String>('town', value);

  String? get image => getField<String>('image');
  set image(String? value) => setField<String>('image', value);
}
