import '../database.dart';

class QuizTable extends SupabaseTable<QuizRow> {
  @override
  String get tableName => 'QUIZ';

  @override
  QuizRow createRow(Map<String, dynamic> data) => QuizRow(data);
}

class QuizRow extends SupabaseDataRow {
  QuizRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => QuizTable();

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  String? get town => getField<String>('town');
  set town(String? value) => setField<String>('town', value);

  String? get stop => getField<String>('stop');
  set stop(String? value) => setField<String>('stop', value);

  String? get user => getField<String>('user');
  set user(String? value) => setField<String>('user', value);

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  String get question => getField<String>('question')!;
  set question(String value) => setField<String>('question', value);
}
