import '../database.dart';

class QuestionTable extends SupabaseTable<QuestionRow> {
  @override
  String get tableName => 'QUESTION';

  @override
  QuestionRow createRow(Map<String, dynamic> data) => QuestionRow(data);
}

class QuestionRow extends SupabaseDataRow {
  QuestionRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => QuestionTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  String? get question => getField<String>('question');
  set question(String? value) => setField<String>('question', value);

  String? get quizz => getField<String>('quizz');
  set quizz(String? value) => setField<String>('quizz', value);

  String? get answer => getField<String>('answer');
  set answer(String? value) => setField<String>('answer', value);

  List<String> get ans1 => getListField<String>('ans1');
  set ans1(List<String>? value) => setListField<String>('ans1', value);
}
