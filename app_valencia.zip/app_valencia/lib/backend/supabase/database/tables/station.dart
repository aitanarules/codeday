import '../database.dart';

class StationTable extends SupabaseTable<StationRow> {
  @override
  String get tableName => 'STATION';

  @override
  StationRow createRow(Map<String, dynamic> data) => StationRow(data);
}

class StationRow extends SupabaseDataRow {
  StationRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => StationTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  double? get latitude => getField<double>('latitude');
  set latitude(double? value) => setField<double>('latitude', value);

  double? get longitude => getField<double>('longitude');
  set longitude(double? value) => setField<double>('longitude', value);

  List<String> get line => getListField<String>('line');
  set line(List<String>? value) => setListField<String>('line', value);

  String? get geometry => getField<String>('geometry');
  set geometry(String? value) => setField<String>('geometry', value);

  String? get type => getField<String>('type');
  set type(String? value) => setField<String>('type', value);

  String? get town => getField<String>('town');
  set town(String? value) => setField<String>('town', value);
}
