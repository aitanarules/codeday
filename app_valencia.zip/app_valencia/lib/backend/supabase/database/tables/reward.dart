import '../database.dart';

class RewardTable extends SupabaseTable<RewardRow> {
  @override
  String get tableName => 'REWARD';

  @override
  RewardRow createRow(Map<String, dynamic> data) => RewardRow(data);
}

class RewardRow extends SupabaseDataRow {
  RewardRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => RewardTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  String? get type => getField<String>('type');
  set type(String? value) => setField<String>('type', value);

  double? get experience => getField<double>('experience');
  set experience(double? value) => setField<double>('experience', value);

  String? get image => getField<String>('image');
  set image(String? value) => setField<String>('image', value);
}
