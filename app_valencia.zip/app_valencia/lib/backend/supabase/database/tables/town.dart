import '../database.dart';

class TownTable extends SupabaseTable<TownRow> {
  @override
  String get tableName => 'TOWN';

  @override
  TownRow createRow(Map<String, dynamic> data) => TownRow(data);
}

class TownRow extends SupabaseDataRow {
  TownRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => TownTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get province => getField<String>('province');
  set province(String? value) => setField<String>('province', value);

  double? get latitude => getField<double>('latitude');
  set latitude(double? value) => setField<double>('latitude', value);

  double? get longitude => getField<double>('longitude');
  set longitude(double? value) => setField<double>('longitude', value);

  String? get address => getField<String>('address');
  set address(String? value) => setField<String>('address', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  String? get reward => getField<String>('reward');
  set reward(String? value) => setField<String>('reward', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  String? get image => getField<String>('image');
  set image(String? value) => setField<String>('image', value);
}
