import '../database.dart';

class EventTable extends SupabaseTable<EventRow> {
  @override
  String get tableName => 'EVENT';

  @override
  EventRow createRow(Map<String, dynamic> data) => EventRow(data);
}

class EventRow extends SupabaseDataRow {
  EventRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => EventTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get title => getField<String>('title');
  set title(String? value) => setField<String>('title', value);

  String? get address => getField<String>('address');
  set address(String? value) => setField<String>('address', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  DateTime? get initialDate => getField<DateTime>('initialDate');
  set initialDate(DateTime? value) => setField<DateTime>('initialDate', value);

  DateTime? get finalDate => getField<DateTime>('finalDate');
  set finalDate(DateTime? value) => setField<DateTime>('finalDate', value);

  String? get reward => getField<String>('reward');
  set reward(String? value) => setField<String>('reward', value);

  String? get town => getField<String>('town');
  set town(String? value) => setField<String>('town', value);
}
