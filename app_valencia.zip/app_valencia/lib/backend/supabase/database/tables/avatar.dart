import '../database.dart';

class AvatarTable extends SupabaseTable<AvatarRow> {
  @override
  String get tableName => 'AVATAR';

  @override
  AvatarRow createRow(Map<String, dynamic> data) => AvatarRow(data);
}

class AvatarRow extends SupabaseDataRow {
  AvatarRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => AvatarTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  String? get gender => getField<String>('gender');
  set gender(String? value) => setField<String>('gender', value);

  String? get image => getField<String>('image');
  set image(String? value) => setField<String>('image', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  String? get gif => getField<String>('gif');
  set gif(String? value) => setField<String>('gif', value);
}
