import '../database.dart';

class UserHasAvatarTable extends SupabaseTable<UserHasAvatarRow> {
  @override
  String get tableName => 'USER_HAS_AVATAR';

  @override
  UserHasAvatarRow createRow(Map<String, dynamic> data) =>
      UserHasAvatarRow(data);
}

class UserHasAvatarRow extends SupabaseDataRow {
  UserHasAvatarRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => UserHasAvatarTable();

  String get idUser => getField<String>('id_user')!;
  set idUser(String value) => setField<String>('id_user', value);

  String get idAvatar => getField<String>('id_avatar')!;
  set idAvatar(String value) => setField<String>('id_avatar', value);
}
