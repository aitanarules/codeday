import '../database.dart';

class UserTable extends SupabaseTable<UserRow> {
  @override
  String get tableName => 'USER';

  @override
  UserRow createRow(Map<String, dynamic> data) => UserRow(data);
}

class UserRow extends SupabaseDataRow {
  UserRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => UserTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  String? get password => getField<String>('password');
  set password(String? value) => setField<String>('password', value);

  DateTime? get birthdate => getField<DateTime>('birthdate');
  set birthdate(DateTime? value) => setField<DateTime>('birthdate', value);

  String? get email => getField<String>('email');
  set email(String? value) => setField<String>('email', value);

  bool? get online => getField<bool>('online');
  set online(bool? value) => setField<bool>('online', value);

  DateTime? get lastAccessDate => getField<DateTime>('lastAccessDate');
  set lastAccessDate(DateTime? value) =>
      setField<DateTime>('lastAccessDate', value);

  double? get level => getField<double>('level');
  set level(double? value) => setField<double>('level', value);

  String? get language => getField<String>('language');
  set language(String? value) => setField<String>('language', value);

  String? get type => getField<String>('type');
  set type(String? value) => setField<String>('type', value);

  double? get music => getField<double>('music');
  set music(double? value) => setField<double>('music', value);

  String? get reward => getField<String>('reward');
  set reward(String? value) => setField<String>('reward', value);

  String? get avatar => getField<String>('avatar');
  set avatar(String? value) => setField<String>('avatar', value);
}
