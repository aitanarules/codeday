import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/custom_code/actions/index.dart' as actions;
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'mapa2_d_widget.dart' show Mapa2DWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Mapa2DModel extends FlutterFlowModel<Mapa2DWidget> {
  ///  Local state fields for this page.

  bool showDetallesButtom = false;

  String munName = 'munName';

  bool isDisable = true;

  List<TownRow> rowListNotNull = [];
  void addToRowListNotNull(TownRow item) => rowListNotNull.add(item);
  void removeFromRowListNotNull(TownRow item) => rowListNotNull.remove(item);
  void removeAtIndexFromRowListNotNull(int index) =>
      rowListNotNull.removeAt(index);
  void insertAtIndexInRowListNotNull(int index, TownRow item) =>
      rowListNotNull.insert(index, item);
  void updateRowListNotNullAtIndex(int index, Function(TownRow) updateFn) =>
      rowListNotNull[index] = updateFn(rowListNotNull[index]);

  List<TownRow> filaActualMunicipio = [];
  void addToFilaActualMunicipio(TownRow item) => filaActualMunicipio.add(item);
  void removeFromFilaActualMunicipio(TownRow item) =>
      filaActualMunicipio.remove(item);
  void removeAtIndexFromFilaActualMunicipio(int index) =>
      filaActualMunicipio.removeAt(index);
  void insertAtIndexInFilaActualMunicipio(int index, TownRow item) =>
      filaActualMunicipio.insert(index, item);
  void updateFilaActualMunicipioAtIndex(
          int index, Function(TownRow) updateFn) =>
      filaActualMunicipio[index] = updateFn(filaActualMunicipio[index]);

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Backend Call - Query Rows] action in Mapa2D widget.
  List<TownRow>? rowList;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
