// Automatic FlutterFlow imports
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your widget name, define your parameter, and then add the
// boilerplate code using the green button on the right!

import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:geolocator/geolocator.dart' as geo;

const MAPBOX_ACCESS_TOKEN =
    'pk.eyJ1Ijoia2lsaWxvdGkiLCJhIjoiY2x2Yjh1d3VnMDVlMjJrcDc5ZHo5YXkwbyJ9.RMPtdqft10pJNyIDMrIjag';

void main(){
  MapboxOptions.setAccessToken(MAPBOX_ACCESS_TOKEN);
  runApp(const MapPage());
}

class MapPage extends StatefulWidget {
  const MapPage({
    super.key,
    this.width,
    this.height,
  });

  final double? width;
  final double? height;

  @override
  State<MapPage> createState() => _MapPageState();
}

class AnnotationClickListener extends OnPointAnnotationClickListener {
  MapboxMap mapboxMap;

  AnnotationClickListener(this.mapboxMap);

  @override
  void onPointAnnotationClick(PointAnnotation annotation) {
    //print("onAnnotationClick, textField: ${annotation.textField}");
    String? coords = annotation.geometry?.toString();
    String? coordinatesString = coords?.split('[')[1].split(']')[0];
    List<String>? coordinatesList = coordinatesString?.split(',');

    double longitude = double.parse(coordinatesList![0]);
    double latitude = double.parse(coordinatesList[1]);

    mapboxMap.flyTo(CameraOptions(
      center:  Point(
          coordinates: Position(
              longitude,
              latitude
          )).toJson(),
      zoom: 18.0,
      pitch: 45.0,
    ), MapAnimationOptions(duration: 2000, startDelay: 0));
  }

}

class _MapPageState extends State<MapPage> {
  _MapPageState();

  MapboxMap? mapboxMap;
  PointAnnotation? pointAnnotation;
  PointAnnotationManager? pointAnnotationManager;

  _onMapCreated(MapboxMap mapboxMap) async{
    await Permission.locationWhenInUse.request();

    this.mapboxMap = mapboxMap;
    DateTime now = DateTime.now();
    int currentHour = now.hour + 2;

    if (currentHour >= 0 && currentHour < 6) {
      mapboxMap.loadStyleJson(await rootBundle.loadString('assets/mapNight.json'));
    } else if (currentHour >= 6 && currentHour < 12) {
      mapboxMap.loadStyleJson(await rootBundle.loadString('assets/mapDay.json'));
    } else if (currentHour >= 12 && currentHour < 18) {
      mapboxMap.loadStyleJson(await rootBundle.loadString('assets/mapDawn.json'));
    } else {
      mapboxMap.loadStyleJson(await rootBundle.loadString('assets/mapDusk.json'));
    }

    geo.Position pos= await _determinePosition();

    //Camara
    mapboxMap.setCamera(CameraOptions(
      center:  Point(
          coordinates: Position(
            pos.longitude,
            pos.latitude,
          )).toJson(),
      zoom: 18.0,
      pitch: 45.0,
    ));

    //Localización
    mapboxMap.location.updateSettings(LocationComponentSettings(
        enabled: true,
        puckBearingEnabled: true,
        puckBearing: PuckBearing.HEADING,
        locationPuck: LocationPuck(
            locationPuck3D: LocationPuck3D(
                modelUri:
                "https://appgchdaqxkcqudowisg.supabase.co/storage/v1/object/public/avatar/avatar/orange/scene.gltf",
              modelScale: [0.1, 0.1, 0.1],
              modelCastShadows: true,
              modelEmissiveStrength: 1.5,
              modelReceiveShadows: true,
              modelScaleMode: ModelScaleMode.MAP,
    ))));

    //Marcadores
    mapboxMap.annotations.createPointAnnotationManager().then((value) async {
      pointAnnotationManager = value;
      final Uint8List image = await loadImageFromAssets('assets/images/marker.png');
      createOneAnnotation(-0.37149170283841715, 39.45503034996972, image);

      var options = <PointAnnotationOptions>[];

      options.add(PointAnnotationOptions(
          geometry: Point(coordinates: Position(-0.5295567,
              39.57252)).toJson(), image: image, iconSize: 6.0));

      options.add(PointAnnotationOptions(
          geometry: Point(coordinates: Position(-0.5324338,
              39.5636455)).toJson(), image: image, iconSize: 6.0));

      options.add(PointAnnotationOptions(
          geometry: Point(coordinates: Position(-0.530186,
              39.566581)).toJson(), image: image, iconSize: 6.0));

      options.add(PointAnnotationOptions(
          geometry: Point(coordinates: Position(-0.533541,
              39.565162)).toJson(), image: image, iconSize: 6.0));

      options.add(PointAnnotationOptions(
          geometry: Point(coordinates: Position(-0.539345,
              39.567555)).toJson(), image: image, iconSize: 6.0));

      options.add(PointAnnotationOptions(
          geometry: Point(coordinates: Position(-0.53333,
              39.56667)).toJson(), image: image, iconSize: 6.0));
      pointAnnotationManager?.createMulti(options);
      pointAnnotationManager
          ?.addOnPointAnnotationClickListener(AnnotationClickListener(mapboxMap));
    });
  }

  Future<Uint8List> loadImageFromAssets(String path) async {
    final byteData = await rootBundle.load(path); // Carga el archivo como ByteData
    return byteData.buffer.asUint8List(); // Convierte ByteData a Uint8List
  }

  @override
  void initState() {
    super.initState();
    mapboxMap?.clearData();
    MapboxOptions.setAccessToken(MAPBOX_ACCESS_TOKEN);
  }

  @override
  void dispose() {
    super.dispose();
  }

  void createOneAnnotation(double lat, double lon, Uint8List icon) {
    pointAnnotationManager
        ?.create(PointAnnotationOptions(
        geometry: Point(
            coordinates: Position(
              -0.37149170283841715,
              39.45503034996972,
            )).toJson(),
        textField: "custom-icon",
        textSize: 0.0,
        textOffset: [0.0, -2.0],
        textColor: Colors.red.value,
        iconSize: 8.0,
        iconOffset: [0.0, -5.0],
        symbolSortKey: 10,
        image: icon))
        .then((value) => pointAnnotation = value);
  }

  /// Determine the current position of the device.
  ///
  /// When the location services are not enabled or permissions
  /// are denied the `Future` will return an error.
  Future<geo.Position> _determinePosition() async {
    bool serviceEnabled;
    geo.LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await geo.Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.
      return Future.error('Location services are disabled.');
    }

    permission = await geo.Geolocator.checkPermission();
    if (permission == geo.LocationPermission.denied) {
      permission = await geo.Geolocator.requestPermission();
      if (permission == geo.LocationPermission.denied) {
        // Permissions are denied, next time you could try
        // requesting permissions again (this is also where
        // Android's shouldShowRequestPermissionRationale
        // returned true. According to Android guidelines
        // your App should show an explanatory UI now.
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == geo.LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }

    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    return await geo.Geolocator.getCurrentPosition();
  }

  @override
  Widget build(BuildContext context) {
    final MapWidget mapWidget =
    MapWidget(key: ValueKey("mapWidget"), onMapCreated: _onMapCreated);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Center(
          child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              child: mapWidget),
        ),
      ],
    );
  }
}