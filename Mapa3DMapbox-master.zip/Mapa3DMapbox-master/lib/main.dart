// Automatic FlutterFlow imports
import 'package:flutterflow_ui/flutterflow_ui.dart';
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your widget name, define your parameter, and then add the
// boilerplate code using the green button on the right!

import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
//import 'page.dart';

const MAPBOX_ACCESS_TOKEN =
    'pk.eyJ1IjoiZWR1YXJkbzExMTE4IiwiYSI6ImNsdW1saGhybTAweDMyam8xcXE2b3Y0OWkifQ.tCEyrYgMwdNPKbCojX_r4A';

class CamaraPage extends StatefulWidget {
  const CamaraPage({
    super.key,
    this.width,
    this.height,
  });

  final double? width;
  final double? height;

  @override
  State<CamaraPage> createState() => _CamaraPageState();
}

void main() {
  runApp(CamaraPage());
}

class _CamaraPageState extends State<CamaraPage> {
  _CamaraPageState();

  MapboxMap? mapboxMap;
  //WebViewController webViewController = WebViewController();

  _onMapCreated(MapboxMap mapboxMap) {
    this.mapboxMap = mapboxMap;
    mapboxMap
        .loadStyleURI('mapbox://styles/eduardo11118/cltsvfn3d00d901p7dlgtfy7j');
    mapboxMap.setCamera(CameraOptions(
      center: {
        'coordinates': Position(39.45, -0.78),
      },
      zoom: 9.0,
      pitch: 45.0,
    ));
  }

  @override
  void initState() {
    super.initState();
    MapboxOptions.setAccessToken(MAPBOX_ACCESS_TOKEN);
  }

  @override
  void dispose() {
    super.dispose();
  }

  Widget _cameraForCoordinateBounds() {
    return TextButton(
      child: Text('cameraForCoordinateBounds'),
      onPressed: () {
        mapboxMap
            ?.cameraForCoordinateBounds(
            CoordinateBounds(
              southwest: {
                'coordinates': Position(1.0, 2.0),
              },
              northeast: {
                'coordinates': Position(3.0, 4.0),
              },
              infiniteBounds: true,
            ),
            MbxEdgeInsets(top: 1, left: 2, bottom: 3, right: 4),
            10,
            20,
            null,
            null)
            .then(
                (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(
                  "Camera zoom: ${value.zoom}, pitch: ${value.pitch}, bearing: ${value.bearing},padding: ${value.padding},center: ${value.center}"),
              backgroundColor: Theme.of(context).primaryColor,
              duration: Duration(seconds: 2),
            )));
      },
    );
  }

  Widget _cameraForCoordinatesCameraOptions() {
    return TextButton(
      child: Text('cameraForCoordinatesCameraOptions'),
      onPressed: () {
        mapboxMap?.cameraForCoordinatesCameraOptions(
            [
              {
                'coordinates': Position(1.0, 2.0),
              },
              {
                'coordinates': Position(3.0, 4.0),
              }
            ],
            CameraOptions(
                center: {
                  'coordinates': Position(1.0, 2.0),
                },
                padding: MbxEdgeInsets(top: 1, left: 2, bottom: 3, right: 4),
                anchor: ScreenCoordinate(x: 1, y: 1),
                zoom: 10,
                bearing: 20,
                pitch: 30),
            ScreenBox(
                min: ScreenCoordinate(x: 0, y: 0),
                max: ScreenCoordinate(x: 100, y: 100))).then(
                (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(
                  "Camera zoom: ${value.zoom}, pitch: ${value.pitch}, bearing: ${value.bearing},padding: ${value.padding},center: ${value.center}"),
              backgroundColor: Theme.of(context).primaryColor,
              duration: Duration(seconds: 2),
            )));
      },
    );
  }

  Widget _cameraForGeometry() {
    return TextButton(
      child: Text('cameraForGeometry'),
      onPressed: () {
        mapboxMap
            ?.cameraForGeometry(
            Point(
                coordinates: Position(
                  1.0,
                  2.0,
                )).toJson(),
            MbxEdgeInsets(top: 1, left: 2, bottom: 3, right: 4),
            10,
            20)
            .then(
                (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(
                  "Camera zoom: ${value.zoom}, pitch: ${value.pitch}, bearing: ${value.bearing},padding: ${value.padding},center: ${value.center}"),
              backgroundColor: Theme.of(context).primaryColor,
              duration: Duration(seconds: 2),
            )));
      },
    );
  }

  Widget _coordinateBoundsForCamera() {
    return TextButton(
      child: Text('coordinateBoundsForCamera'),
      onPressed: () {
        mapboxMap
            ?.coordinateBoundsForCamera(CameraOptions(
            center: {
              'coordinates': Position(
                1.0,
                2.0,
              )
            },
            padding: MbxEdgeInsets(top: 1, left: 2, bottom: 3, right: 4),
            anchor: ScreenCoordinate(x: 1, y: 1),
            zoom: 10,
            bearing: 20,
            pitch: 30))
            .then(
                (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(
                  "coordinateBounds  northeast: ${value.northeast}, southwest: ${value.southwest}, infiniteBounds: ${value.infiniteBounds}"),
              backgroundColor: Theme.of(context).primaryColor,
              duration: Duration(seconds: 2),
            )));
      },
    );
  }

  Widget _coordinateBoundsForCameraUnwrapped() {
    return TextButton(
      child: Text('coordinateBoundsForCameraUnwrapped'),
      onPressed: () {
        mapboxMap
            ?.coordinateBoundsForCameraUnwrapped(CameraOptions(
            center: {
              'coordinates': Position(
                1.0,
                2.0,
              )
            },
            padding: MbxEdgeInsets(top: 1, left: 2, bottom: 3, right: 4),
            anchor: ScreenCoordinate(x: 1, y: 1),
            zoom: 10,
            bearing: 20,
            pitch: 30))
            .then(
                (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text("coordinateBounds: ${value.encode()}"),
              backgroundColor: Theme.of(context).primaryColor,
              duration: Duration(seconds: 2),
            )));
      },
    );
  }

  Widget _coordinateBoundsZoomForCamera() {
    return TextButton(
      child: Text('coordinateBoundsZoomForCamera'),
      onPressed: () {
        mapboxMap
            ?.coordinateBoundsZoomForCamera(CameraOptions(
            center: {
              'coordinates': Position(
                1.0,
                2.0,
              )
            },
            padding: MbxEdgeInsets(top: 1, left: 2, bottom: 3, right: 4),
            anchor: ScreenCoordinate(x: 1, y: 1),
            zoom: 10,
            bearing: 20,
            pitch: 30))
            .then(
                (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text("coordinateBounds: ${value.encode()}"),
              backgroundColor: Theme.of(context).primaryColor,
              duration: Duration(seconds: 2),
            )));
      },
    );
  }

  Widget _coordinateBoundsZoomForCameraUnwrapped() {
    return TextButton(
      child: Text('coordinateBoundsZoomForCameraUnwrapped'),
      onPressed: () {
        mapboxMap
            ?.coordinateBoundsZoomForCameraUnwrapped(CameraOptions(
            center: {
              'coordinates': Position(
                1.0,
                2.0,
              )
            },
            padding: MbxEdgeInsets(top: 1, left: 2, bottom: 3, right: 4),
            anchor: ScreenCoordinate(x: 1, y: 1),
            zoom: 10,
            bearing: 20,
            pitch: 30))
            .then(
                (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text("coordinateBounds: ${value.encode()}"),
              backgroundColor: Theme.of(context).primaryColor,
              duration: Duration(seconds: 2),
            )));
      },
    );
  }

  Widget _pixelForCoordinate() {
    return TextButton(
      child: Text('pixelForCoordinate'),
      onPressed: () {
        mapboxMap?.pixelForCoordinate({
          'coordinates': Position(
            1.0,
            2.0,
          )
        }).then((value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text("ScreenCoordinate x: ${value.x}, y: ${value.y}"),
          backgroundColor: Theme.of(context).primaryColor,
          duration: Duration(seconds: 2),
        )));
      },
    );
  }

  Widget _pixelsForCoordinates() {
    return TextButton(
      child: Text('pixelsForCoordinates'),
      onPressed: () {
        mapboxMap?.pixelsForCoordinates([
          {
            'coordinates': Position(
              1.0,
              2.0,
            )
          },
          {
            'coordinates': Position(
              2.0,
              3.0,
            )
          }
        ]).then((value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
              "ScreenCoordinate x: ${value.first?.x}, y: ${value.first?.y}"),
          backgroundColor: Theme.of(context).primaryColor,
          duration: Duration(seconds: 2),
        )));
      },
    );
  }

  Widget _coordinateForPixel() {
    return TextButton(
      child: Text('coordinateForPixel'),
      onPressed: () {
        mapboxMap
            ?.coordinateForPixel(ScreenCoordinate(x: 100, y: 100))
            .then((point) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
                "Point latitude: ${point.toString()}, longitude: ${point.toString()}"),
            backgroundColor: Theme.of(context).primaryColor,
            duration: Duration(seconds: 2),
          ));
        });
      },
    );
  }

  Widget _coordinatesForPixels() {
    return TextButton(
      child: Text('coordinatesForPixels'),
      onPressed: () {
        mapboxMap?.coordinatesForPixels([
          ScreenCoordinate(x: 100, y: 100),
          ScreenCoordinate(x: 200, y: 300)
        ]).then((value) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Points ${value.first}"),
            backgroundColor: Theme.of(context).primaryColor,
            duration: Duration(seconds: 2),
          ));
        });
      },
    );
  }

  Widget _setCamera() {
    return TextButton(
      child: Text('setCamera'),
      onPressed: () {
        mapboxMap?.setCamera(CameraOptions(
            center: {
              'coordinates': Position(
                0.381457,
                6.687337,
              )
            },
            padding: MbxEdgeInsets(top: 1, left: 2, bottom: 3, right: 4),
            anchor: ScreenCoordinate(x: 1, y: 1),
            zoom: 3,
            bearing: 20,
            pitch: 30));
      },
    );
  }

  Widget _getCameraState() {
    return TextButton(
      child: Text('getCameraState'),
      onPressed: () {
        mapboxMap?.getCameraState().then(
                (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(
                  "Camera state zoom: ${value.zoom}, pitch: ${value.pitch}, bearing: ${value.bearing},padding: ${value.padding},center: ${value.center}"),
              backgroundColor: Theme.of(context).primaryColor,
              duration: Duration(seconds: 2),
            )));
      },
    );
  }

  Widget _setBounds() {
    return TextButton(
      child: Text('setBounds'),
      onPressed: () {
        mapboxMap?.setBounds(CameraBoundsOptions(
            bounds: CoordinateBounds(southwest: {
              'coordinates': Position(
                1.0,
                2.0,
              )
            }, northeast: {
              'coordinates': Position(
                3.0,
                4.0,
              )
            }, infiniteBounds: true),
            maxZoom: 10,
            minZoom: 0,
            maxPitch: 10,
            minPitch: 0));
      },
    );
  }

  Widget _getBounds() {
    return TextButton(
      child: Text('getBounds'),
      onPressed: () {
        mapboxMap?.getBounds().then(
                (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(
                  "Bounds minZoom: ${value.minZoom}, maxZoom: ${value.maxZoom}, minPitch: ${value.minPitch},maxPitch: ${value.maxPitch},northeast: ${value.bounds.northeast}"),
              backgroundColor: Theme.of(context).primaryColor,
              duration: Duration(seconds: 2),
            )));
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final MapWidget mapWidget =
    MapWidget(key: ValueKey("mapWidget"), onMapCreated: _onMapCreated);

    final List<Widget> listViewChildren = <Widget>[];

    listViewChildren.addAll(
      <Widget>[
        _cameraForCoordinateBounds(),
        _cameraForCoordinatesCameraOptions(),
        _cameraForGeometry(),
        _coordinateBoundsForCamera(),
        _coordinateBoundsForCameraUnwrapped(),
        _coordinateBoundsZoomForCamera(),
        _coordinateBoundsZoomForCameraUnwrapped(),
        _pixelForCoordinate(),
        _pixelsForCoordinates(),
        _coordinateForPixel(),
        _coordinatesForPixels(),
        _setCamera(),
        _getCameraState(),
        _setBounds(),
        _getBounds(),
      ],
    );

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Center(
          child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height - 400,
              child: mapWidget),
        ),
        Expanded(
          child: ListView(
            children: listViewChildren,
          ),
        )
      ],
    );
  }
}