package com.example.mapa3dmapbox

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
